function fFFoter(){
    return(
        <footer>""</footer>
    )
}

export default fFFoter;